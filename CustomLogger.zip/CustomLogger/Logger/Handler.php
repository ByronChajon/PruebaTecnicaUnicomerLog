<?php
namespace Unicomer\CustomLogger\Logger;

use Monolog\Logger;
use Magento\Framework\Filesystem\DriverInterface;

class Handler extends \Monolog\Handler\StreamHandler
{
    public function __construct(
        DriverInterface $filesystem,
        $filePath = 'var/log/customlogger.log', // Asegúrate de usar el archivo log correcto
        $filePermissions = null
    ) {
        $logPath = $filesystem->getAbsolutePath($filePath);
        parent::__construct($logPath, Logger::DEBUG);
    }
}
