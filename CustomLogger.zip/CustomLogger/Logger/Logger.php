<?php
namespace Unicomer\CustomLogger\Logger;

class Logger extends \Monolog\Logger
{
}
