<?php
namespace Unicomer\CustomLogger\Controller\Adminhtml\System;

class Log extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Unicomer_CustomLogger::log';

    protected $logger;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Unicomer\CustomLogger\Logger\Logger $logger
    ) {
        parent::__construct($context);
        $this->logger = $logger;
    }

    public function execute()
    {
        $this->logger->info('El botón de log personalizado fue presionado.');
        $this->messageManager->addSuccessMessage(__('El log personalizado fue registrado.'));
        $this->_redirect('adminhtml/system_config/edit/section/unicomer_customlogger_section');
    }
}
