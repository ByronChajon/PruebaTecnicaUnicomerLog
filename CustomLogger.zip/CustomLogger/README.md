# Mage2 Module Unicomer CustomLogger

``unicomer/module-customlogger``

- [Main Functionalities](#markdown-header-main-functionalities)
- [Installation](#markdown-header-installation)
- [Configuration](#markdown-header-configuration)
- [Specifications](#markdown-header-specifications)
- [Attributes](#markdown-header-attributes)

## Main Functionalities
- Adds a custom button in the Magento backend under **Stores > Configuration > Custom Logger**.
- Logs a custom message (`"El botón de log personalizado fue presionado."`) into the `system.log` file when the button is clicked.
- Useful for testing or integrating logging functionality in Magento 2 projects.

## Installation
\* = in production, please use the `--keep-generated` option

### Type 1: Zip file
- Unzip the zip file in `app/code/Unicomer`
- Enable the module by running `php bin/magento module:enable Unicomer_CustomLogger`
- Apply database updates by running `php bin/magento setup:upgrade`\*
- Flush the cache by running `php bin/magento cache:flush`

### Type 2: Composer
- Make the module available in a composer repository, for example:
  - Private repository `repo.magento.com`
  - Public repository `packagist.org`
  - Public GitHub repository as VCS
- Add the composer repository to the configuration by running:
  ```bash
  composer config repositories.repo.magento.com composer https://repo.magento.com/

````Al finalizar se muestra el botón solicitado, en la ruta 
Stores > Configuration > General > Custom Logger > Settings
