<?php
namespace Unicomer\CustomLogger\Block\Adminhtml\System\Config;

class Button extends \Magento\Config\Block\System\Config\Form\Field
{
    protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $data = [
            'id' => $element->getHtmlId(),
            'label' => __('Registrar'),
        ];
        $html = '<button type="button"' . $this->_decorateRowHtml($element, $this->getLayout()->createBlock(\Magento\Backend\Block\Template::class)->setTemplate('Unicomer_CustomLogger::system/config/button.phtml')->setData($data)->toHtml()) . '</button>';
        return $html;
    }
}
